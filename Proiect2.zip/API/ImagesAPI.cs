﻿using System.Collections.Generic;
using System.Text;
using Proiect1_DotNet;

namespace API
{
    public class ImagesAPI
    {
        public void insertImage(string Name, string Path, string Description, string Location, string Persons)
        {
            using (ImagesModelContainer context = new ImagesModelContainer())
            {
                Images image = new Images()
                {
                    Name = Name,
                    Path = Path,
                    Description = Description,
                    Deleted = false
                };

                Location location = new Location() {
                    Name = Location,
                    Image = image
                };

                context.Images.Add(image);
                context.Locations.Add(location); 

                string[] personsList = Persons.Split(',');
                for (var i = 0; i < personsList.Length; i++){
                    Person person = new Person()
                    {
                        Name = personsList[i].Trim(' '),
                        Image = image
                    };
                    context.People.Add(person);
                }

                context.SaveChanges();
            }
        }

        public Dictionary<int, string> getImages()
        {
            Dictionary<int, string> toReturn = new Dictionary<int, string>();
            using (ImagesModelContainer context = new ImagesModelContainer())
            {
                foreach(Images image in context.Images) 
                {
                    if (image.Deleted == false)
                    {
                        toReturn.Add(image.Id, image.Name);
                    }
                }
            }
            return toReturn;
        }
        
        public void deleteImage(int id)
        {
            using (ImagesModelContainer context = new ImagesModelContainer())
            {
                foreach (Images image in context.Images)
                {
                    if(image.Id == id)
                    {
                        image.Deleted = true;
                        break;
                    }
                }
                context.SaveChanges();
            }
        }

        public Dictionary<string, string> getImageData(int id)
        {
            Dictionary<string, string> toReturn = new Dictionary<string, string>();
            using (ImagesModelContainer context = new ImagesModelContainer())
            {
                foreach (Images image in context.Images)
                {
                    if (image.Id == id)
                    {
                        toReturn.Add("Name", image.Name);
                        toReturn.Add("Path", image.Path);
                        toReturn.Add("Description", image.Description);
                        break;
                    }
                }

                foreach(Location location in context.Locations)
                {
                    if(location.Image.Id == id)
                    {
                        toReturn.Add("Location", location.Name);
                        break;
                    }
                }

                StringBuilder names = new StringBuilder();
                foreach (Person person in context.People)
                {
                    if(person.Image.Id == id)
                    {
                        names.Append(person.Name);
                        names.Append(", ");
                    }
                }
                string personsNames = names.ToString();
                toReturn.Add("Persons", personsNames.Substring(0, personsNames.Length - 2));
            }
            return toReturn;
        }

        public void updateImage(int id, string Name, string Path, string Description, string Location, string Persons)
        {
            using (ImagesModelContainer context = new ImagesModelContainer())
            {
                Images imageAux = null;
                foreach (Images image in context.Images)
                {
                    if (image.Id == id)
                    {
                        image.Name = Name;
                        image.Path = Path;
                        image.Description = Description;
                        imageAux = image;
                        break;
                    }
                }

                foreach (Location location in context.Locations)
                {
                    if (location.Image.Id == id)
                    {
                        location.Name = Location;
                        break;
                    }
                }

                foreach (Person person in context.People)
                {
                    if (person.Image.Id == id)
                    {
                        context.People.Remove(person);
                    }
                }

                string[] personsList = Persons.Split(',');
                for (var i = 0; i < personsList.Length; i++)
                {
                    Person person = new Person()
                    {
                        Name = personsList[i].Trim(' '),
                        Image = imageAux
                    };
                    context.People.Add(person);
                }

                context.SaveChanges();
            }
        }
    }
}
