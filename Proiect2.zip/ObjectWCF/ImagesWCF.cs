﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API;

namespace ObjectWCF
{
    public class ImagesWCF : IImages
    {
        public void insertImage(string name, string path, string description, string location, string persons)
        {
            ImagesAPI image = new ImagesAPI();
            image.insertImage(name, path, description, location, persons );
        }

        public Dictionary<int, string> getImages()
        {
            ImagesAPI images = new ImagesAPI();
            return images.getImages();
        }

        public void deleteImage(int id)
        {
            ImagesAPI image = new ImagesAPI();
            image.deleteImage(id);
        }

        public Dictionary<string, string> getImageData(int id)
        {
            ImagesAPI image = new ImagesAPI();
            return image.getImageData(id);
        }

        public void updateImage(int id, string name, string path, string description, string location, string persons)
        {
            ImagesAPI image = new ImagesAPI();
            image.updateImage(id, name, path, description, location, persons);
        }
    }
}
