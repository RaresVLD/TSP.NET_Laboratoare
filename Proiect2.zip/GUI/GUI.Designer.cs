﻿namespace GUI
{
    partial class GUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.imageName = new System.Windows.Forms.TextBox();
            this.imagePath = new System.Windows.Forms.TextBox();
            this.imageDescription = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.insertButton = new System.Windows.Forms.Button();
            this.imagesList = new System.Windows.Forms.ComboBox();
            this.deleteButton = new System.Windows.Forms.Button();
            this.deleteImageLabel = new System.Windows.Forms.Label();
            this.imageLocation = new System.Windows.Forms.TextBox();
            this.imageLocationLabel = new System.Windows.Forms.Label();
            this.imagePersons = new System.Windows.Forms.TextBox();
            this.imagePersonsLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.editButton = new System.Windows.Forms.Button();
            this.editNameText = new System.Windows.Forms.TextBox();
            this.editPathText = new System.Windows.Forms.TextBox();
            this.editDescriptionText = new System.Windows.Forms.TextBox();
            this.editLocationText = new System.Windows.Forms.TextBox();
            this.editPersonsText = new System.Windows.Forms.TextBox();
            this.editNameLabel = new System.Windows.Forms.Label();
            this.editPathLabel = new System.Windows.Forms.Label();
            this.editDescriptionLabel = new System.Windows.Forms.Label();
            this.editLocationLabel = new System.Windows.Forms.Label();
            this.editPersonsLabel = new System.Windows.Forms.Label();
            this.updateButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.selectImage = new System.Windows.Forms.Button();
            this.openFileDialogImage = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // imageName
            // 
            this.imageName.Location = new System.Drawing.Point(109, 46);
            this.imageName.Name = "imageName";
            this.imageName.Size = new System.Drawing.Size(171, 20);
            this.imageName.TabIndex = 0;
            // 
            // imagePath
            // 
            this.imagePath.Location = new System.Drawing.Point(109, 72);
            this.imagePath.Name = "imagePath";
            this.imagePath.Size = new System.Drawing.Size(171, 20);
            this.imagePath.TabIndex = 1;
            // 
            // imageDescription
            // 
            this.imageDescription.Location = new System.Drawing.Point(109, 98);
            this.imageDescription.Name = "imageDescription";
            this.imageDescription.Size = new System.Drawing.Size(171, 20);
            this.imageDescription.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Image Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Image Path";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Image Description";
            // 
            // insertButton
            // 
            this.insertButton.Location = new System.Drawing.Point(109, 231);
            this.insertButton.Name = "insertButton";
            this.insertButton.Size = new System.Drawing.Size(171, 28);
            this.insertButton.TabIndex = 6;
            this.insertButton.Text = "Insert";
            this.insertButton.UseVisualStyleBackColor = true;
            this.insertButton.Click += new System.EventHandler(this.insertButton_Click);
            // 
            // imagesList
            // 
            this.imagesList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.imagesList.FormattingEnabled = true;
            this.imagesList.Location = new System.Drawing.Point(600, 15);
            this.imagesList.Name = "imagesList";
            this.imagesList.Size = new System.Drawing.Size(188, 21);
            this.imagesList.TabIndex = 7;
            this.imagesList.SelectedIndexChanged += new System.EventHandler(this.imagesList_SelectedIndexChanged);
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(600, 45);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(188, 43);
            this.deleteButton.TabIndex = 9;
            this.deleteButton.Text = "Delete";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // deleteImageLabel
            // 
            this.deleteImageLabel.AutoSize = true;
            this.deleteImageLabel.Location = new System.Drawing.Point(503, 18);
            this.deleteImageLabel.Name = "deleteImageLabel";
            this.deleteImageLabel.Size = new System.Drawing.Size(93, 13);
            this.deleteImageLabel.TabIndex = 10;
            this.deleteImageLabel.Text = "Delete/Edit Image";
            // 
            // imageLocation
            // 
            this.imageLocation.Location = new System.Drawing.Point(109, 124);
            this.imageLocation.Name = "imageLocation";
            this.imageLocation.Size = new System.Drawing.Size(171, 20);
            this.imageLocation.TabIndex = 11;
            // 
            // imageLocationLabel
            // 
            this.imageLocationLabel.AutoSize = true;
            this.imageLocationLabel.Location = new System.Drawing.Point(12, 127);
            this.imageLocationLabel.Name = "imageLocationLabel";
            this.imageLocationLabel.Size = new System.Drawing.Size(80, 13);
            this.imageLocationLabel.TabIndex = 12;
            this.imageLocationLabel.Text = "Image Location";
            // 
            // imagePersons
            // 
            this.imagePersons.Location = new System.Drawing.Point(109, 171);
            this.imagePersons.Name = "imagePersons";
            this.imagePersons.Size = new System.Drawing.Size(171, 20);
            this.imagePersons.TabIndex = 13;
            // 
            // imagePersonsLabel
            // 
            this.imagePersonsLabel.AutoSize = true;
            this.imagePersonsLabel.Location = new System.Drawing.Point(12, 174);
            this.imagePersonsLabel.Name = "imagePersonsLabel";
            this.imagePersonsLabel.Size = new System.Drawing.Size(77, 13);
            this.imagePersonsLabel.TabIndex = 14;
            this.imagePersonsLabel.Text = "Image Persons";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(151, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Comma Separated!";
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(600, 94);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(188, 42);
            this.editButton.TabIndex = 16;
            this.editButton.Text = "Edit";
            this.editButton.UseVisualStyleBackColor = true;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // editNameText
            // 
            this.editNameText.Location = new System.Drawing.Point(600, 144);
            this.editNameText.Name = "editNameText";
            this.editNameText.Size = new System.Drawing.Size(188, 20);
            this.editNameText.TabIndex = 17;
            this.editNameText.Visible = false;
            // 
            // editPathText
            // 
            this.editPathText.Location = new System.Drawing.Point(600, 170);
            this.editPathText.Name = "editPathText";
            this.editPathText.Size = new System.Drawing.Size(188, 20);
            this.editPathText.TabIndex = 18;
            this.editPathText.Visible = false;
            // 
            // editDescriptionText
            // 
            this.editDescriptionText.Location = new System.Drawing.Point(600, 196);
            this.editDescriptionText.Name = "editDescriptionText";
            this.editDescriptionText.Size = new System.Drawing.Size(188, 20);
            this.editDescriptionText.TabIndex = 19;
            this.editDescriptionText.Visible = false;
            // 
            // editLocationText
            // 
            this.editLocationText.Location = new System.Drawing.Point(600, 222);
            this.editLocationText.Name = "editLocationText";
            this.editLocationText.Size = new System.Drawing.Size(188, 20);
            this.editLocationText.TabIndex = 20;
            this.editLocationText.Visible = false;
            // 
            // editPersonsText
            // 
            this.editPersonsText.Location = new System.Drawing.Point(600, 248);
            this.editPersonsText.Name = "editPersonsText";
            this.editPersonsText.Size = new System.Drawing.Size(188, 20);
            this.editPersonsText.TabIndex = 21;
            this.editPersonsText.Visible = false;
            // 
            // editNameLabel
            // 
            this.editNameLabel.AutoSize = true;
            this.editNameLabel.Location = new System.Drawing.Point(515, 147);
            this.editNameLabel.Name = "editNameLabel";
            this.editNameLabel.Size = new System.Drawing.Size(56, 13);
            this.editNameLabel.TabIndex = 22;
            this.editNameLabel.Text = "Edit Name";
            this.editNameLabel.Visible = false;
            // 
            // editPathLabel
            // 
            this.editPathLabel.AutoSize = true;
            this.editPathLabel.Location = new System.Drawing.Point(515, 173);
            this.editPathLabel.Name = "editPathLabel";
            this.editPathLabel.Size = new System.Drawing.Size(50, 13);
            this.editPathLabel.TabIndex = 23;
            this.editPathLabel.Text = "Edit Path";
            this.editPathLabel.Visible = false;
            // 
            // editDescriptionLabel
            // 
            this.editDescriptionLabel.AutoSize = true;
            this.editDescriptionLabel.Location = new System.Drawing.Point(515, 199);
            this.editDescriptionLabel.Name = "editDescriptionLabel";
            this.editDescriptionLabel.Size = new System.Drawing.Size(81, 13);
            this.editDescriptionLabel.TabIndex = 24;
            this.editDescriptionLabel.Text = "Edit Description";
            this.editDescriptionLabel.Visible = false;
            // 
            // editLocationLabel
            // 
            this.editLocationLabel.AutoSize = true;
            this.editLocationLabel.Location = new System.Drawing.Point(515, 225);
            this.editLocationLabel.Name = "editLocationLabel";
            this.editLocationLabel.Size = new System.Drawing.Size(69, 13);
            this.editLocationLabel.TabIndex = 25;
            this.editLocationLabel.Text = "Edit Location";
            this.editLocationLabel.Visible = false;
            // 
            // editPersonsLabel
            // 
            this.editPersonsLabel.AutoSize = true;
            this.editPersonsLabel.Location = new System.Drawing.Point(515, 251);
            this.editPersonsLabel.Name = "editPersonsLabel";
            this.editPersonsLabel.Size = new System.Drawing.Size(66, 13);
            this.editPersonsLabel.TabIndex = 26;
            this.editPersonsLabel.Text = "Edit Persons";
            this.editPersonsLabel.Visible = false;
            // 
            // updateButton
            // 
            this.updateButton.Location = new System.Drawing.Point(600, 274);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(188, 42);
            this.updateButton.TabIndex = 27;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Visible = false;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(104, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(176, 29);
            this.label5.TabIndex = 28;
            this.label5.Text = "Fill every field!";
            // 
            // selectImage
            // 
            this.selectImage.Location = new System.Drawing.Point(109, 197);
            this.selectImage.Name = "selectImage";
            this.selectImage.Size = new System.Drawing.Size(171, 28);
            this.selectImage.TabIndex = 29;
            this.selectImage.Text = "Select Image";
            this.selectImage.UseVisualStyleBackColor = true;
            this.selectImage.Click += new System.EventHandler(this.selectImage_Click);
            // 
            // openFileDialogImage
            // 
            this.openFileDialogImage.FileName = "openFileDialogImage";
            // 
            // GUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.selectImage);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.editPersonsLabel);
            this.Controls.Add(this.editLocationLabel);
            this.Controls.Add(this.editDescriptionLabel);
            this.Controls.Add(this.editPathLabel);
            this.Controls.Add(this.editNameLabel);
            this.Controls.Add(this.editPersonsText);
            this.Controls.Add(this.editLocationText);
            this.Controls.Add(this.editDescriptionText);
            this.Controls.Add(this.editPathText);
            this.Controls.Add(this.editNameText);
            this.Controls.Add(this.editButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.imagePersonsLabel);
            this.Controls.Add(this.imagePersons);
            this.Controls.Add(this.imageLocationLabel);
            this.Controls.Add(this.imageLocation);
            this.Controls.Add(this.deleteImageLabel);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.imagesList);
            this.Controls.Add(this.insertButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.imageDescription);
            this.Controls.Add(this.imagePath);
            this.Controls.Add(this.imageName);
            this.Name = "GUI";
            this.Text = "GUI";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox imageName;
        private System.Windows.Forms.TextBox imagePath;
        private System.Windows.Forms.TextBox imageDescription;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button insertButton;
        private System.Windows.Forms.ComboBox imagesList;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Label deleteImageLabel;
        private System.Windows.Forms.TextBox imageLocation;
        private System.Windows.Forms.Label imageLocationLabel;
        private System.Windows.Forms.TextBox imagePersons;
        private System.Windows.Forms.Label imagePersonsLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button editButton;
        private System.Windows.Forms.TextBox editNameText;
        private System.Windows.Forms.TextBox editPathText;
        private System.Windows.Forms.TextBox editDescriptionText;
        private System.Windows.Forms.TextBox editLocationText;
        private System.Windows.Forms.TextBox editPersonsText;
        private System.Windows.Forms.Label editNameLabel;
        private System.Windows.Forms.Label editPathLabel;
        private System.Windows.Forms.Label editDescriptionLabel;
        private System.Windows.Forms.Label editLocationLabel;
        private System.Windows.Forms.Label editPersonsLabel;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button selectImage;
        private System.Windows.Forms.OpenFileDialog openFileDialogImage;
    }
}

