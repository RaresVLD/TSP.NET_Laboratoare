﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using API;

namespace GUI
{
    public partial class GUI : Form
    {
        public GUI()
        {
            InitializeComponent();
            refreshDeletedImages();
        }

        private void insertButton_Click(object sender, EventArgs e)
        {
            if (imageName.Text.Length > 0 &&
                imagePath.Text.Length > 0 &&
                imageDescription.Text.Length > 0 &&
                imageLocation.Text.Length > 0 &&
                imagePersons.Text.Length > 0
                )
            {
                ImagesAPI imagesAPI = new ImagesAPI();
                imagesAPI.insertImage(imageName.Text, imagePath.Text, imageDescription.Text, imageLocation.Text, imagePersons.Text);
                refreshDeletedImages();
                clearInsertFields();
            }
        }

        private void refreshDeletedImages()
        {
            ImagesAPI imagesAPI = new ImagesAPI();
            Dictionary<int, string> images = imagesAPI.getImages();
            imagesList.DataSource = null;

            if (images.Count > 0)
            {
                imagesList.DataSource = new BindingSource(images, null);
                imagesList.DisplayMember = "Value";
                imagesList.ValueMember = "Key";
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            int id = (int)imagesList.SelectedValue;
            ImagesAPI imagesAPI = new ImagesAPI();
            imagesAPI.deleteImage(id);
            refreshDeletedImages();

            clearEditFields();
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            int id = (int)imagesList.SelectedValue;
            ImagesAPI imagesAPI = new ImagesAPI();
            Dictionary<string, string> image = imagesAPI.getImageData(id);

            editNameLabel.Show();
            editNameText.Text = image["Name"];
            editNameText.Show();

            editPathLabel.Show();
            editPathText.Text = image["Path"];
            editPathText.Show();

            editDescriptionLabel.Show();
            editDescriptionText.Text = image["Description"];
            editDescriptionText.Show();

            editLocationLabel.Show();
            editLocationText.Text = image["Location"];
            editLocationText.Show();

            editPersonsLabel.Show();
            editPersonsText.Text = image["Persons"];
            editPersonsText.Show();

            updateButton.Show();
        }

        private void imagesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearEditFields();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            int id = (int)imagesList.SelectedValue;
            ImagesAPI imagesAPI = new ImagesAPI();
            string editName = editNameText.Text;
            string editPath = editPathText.Text;
            string editDescription = editDescriptionText.Text;
            string editLocation = editLocationText.Text;
            string editPersons = editPersonsText.Text;
            imagesAPI.updateImage(id, editName, editPath, editDescription, editLocation, editPersons);
            clearEditFields();
        }

        public void clearEditFields()
        {
            editNameLabel.Hide();
            editNameText.Text = "";
            editNameText.Hide();

            editPathLabel.Hide();
            editPathText.Text = "";
            editPathText.Hide();

            editDescriptionLabel.Hide();
            editDescriptionText.Text = "";
            editDescriptionText.Hide();

            editLocationLabel.Hide();
            editLocationText.Text = "";
            editLocationText.Hide();

            editPersonsLabel.Hide();
            editPersonsText.Text = "";
            editPersonsText.Hide();

            updateButton.Hide();
        }

        public void clearInsertFields()
        {
            imageName.Text = "";
            imagePath.Text = "";
            imageDescription.Text = "";
            imageLocation.Text = "";
            imagePersons.Text = "";
        }

        private void selectImage_Click(object sender, EventArgs e)
        {
            DialogResult image = openFileDialogImage.ShowDialog();
            if (image == DialogResult.OK) // Test result.
            {
                imagePath.Text = openFileDialogImage.FileName;
                imageName.Text = System.IO.Path.GetFileNameWithoutExtension(openFileDialogImage.FileName);
            }
        }
    }
}
