﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClientImages
{
    public partial class ClientImagesGUI : Form
    {
        public ClientImagesGUI()
        {
            InitializeComponent();
            refreshDeletedImages();
        }

        private void insertButton_Click(object sender, EventArgs e)
        {
            if (imageName.Text.Length > 0 &&
                imagePath.Text.Length > 0 &&
                imageDescription.Text.Length > 0 &&
                imageLocation.Text.Length > 0 &&
                imagePersons.Text.Length > 0
                )
            {
                ImagesClient imagesAPI = new ImagesClient();
                imagesAPI.insertImage(imageName.Text, imagePath.Text, imageDescription.Text, imageLocation.Text, imagePersons.Text);
                refreshDeletedImages();
                clearInsertFields();
            }
        }

        private void refreshDeletedImages()
        {
            ImagesClient imagesAPI = new ImagesClient();
            Dictionary<int, string> images = imagesAPI.getImages();
            imagesList.DataSource = null;

            if (images.Count > 0)
            {
                imagesList.DataSource = new BindingSource(images, null);
                imagesList.DisplayMember = "Value";
                imagesList.ValueMember = "Key";
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            int id = (int)imagesList.SelectedValue;
            ImagesClient imagesAPI = new ImagesClient();
            imagesAPI.deleteImage(id);
            refreshDeletedImages();

            clearEditFields();
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            int id = (int)imagesList.SelectedValue;
            ImagesClient imagesAPI = new ImagesClient();
            Dictionary<string, string> image = imagesAPI.getImageData(id);

            editNameLabel.Show();
            editNameText.Text = image["Name"];
            editNameText.Show();

            editPathLabel.Show();
            editPathText.Text = image["Path"];
            editPathText.Show();

            editDescriptionLabel.Show();
            editDescriptionText.Text = image["Description"];
            editDescriptionText.Show();

            editLocationLabel.Show();
            editLocationText.Text = image["Location"];
            editLocationText.Show();

            editPersonsLabel.Show();
            editPersonsText.Text = image["Persons"];
            editPersonsText.Show();

            updateButton.Show();
        }

        private void imagesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearEditFields();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            int id = (int)imagesList.SelectedValue;
            ImagesClient imagesAPI = new ImagesClient();
            string editName = editNameText.Text;
            string editPath = editPathText.Text;
            string editDescription = editDescriptionText.Text;
            string editLocation = editLocationText.Text;
            string editPersons = editPersonsText.Text;
            imagesAPI.updateImage(id, editName, editPath, editDescription, editLocation, editPersons);
            clearEditFields();
            refreshDeletedImages();
        }

        public void clearEditFields()
        {
            editNameLabel.Hide();
            editNameText.Text = "";
            editNameText.Hide();

            editPathLabel.Hide();
            editPathText.Text = "";
            editPathText.Hide();

            editDescriptionLabel.Hide();
            editDescriptionText.Text = "";
            editDescriptionText.Hide();

            editLocationLabel.Hide();
            editLocationText.Text = "";
            editLocationText.Hide();

            editPersonsLabel.Hide();
            editPersonsText.Text = "";
            editPersonsText.Hide();

            updateButton.Hide();
        }

        public void clearInsertFields()
        {
            imageName.Text = "";
            imagePath.Text = "";
            imageDescription.Text = "";
            imageLocation.Text = "";
            imagePersons.Text = "";
        }

        private void selectImage_Click(object sender, EventArgs e)
        {
            DialogResult image = openFileDialogImage.ShowDialog();
            if (image == DialogResult.OK) // Test result.
            {
                imagePath.Text = openFileDialogImage.FileName;
                imageName.Text = System.IO.Path.GetFileNameWithoutExtension(openFileDialogImage.FileName);
            }
        }

    }
}
