﻿namespace ClientImages
{
    partial class ClientImagesGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.selectImage = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.updateButton = new System.Windows.Forms.Button();
            this.editPersonsLabel = new System.Windows.Forms.Label();
            this.editLocationLabel = new System.Windows.Forms.Label();
            this.editDescriptionLabel = new System.Windows.Forms.Label();
            this.editPathLabel = new System.Windows.Forms.Label();
            this.editNameLabel = new System.Windows.Forms.Label();
            this.editPersonsText = new System.Windows.Forms.TextBox();
            this.editLocationText = new System.Windows.Forms.TextBox();
            this.editDescriptionText = new System.Windows.Forms.TextBox();
            this.editPathText = new System.Windows.Forms.TextBox();
            this.editNameText = new System.Windows.Forms.TextBox();
            this.editButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.imagePersonsLabel = new System.Windows.Forms.Label();
            this.imagePersons = new System.Windows.Forms.TextBox();
            this.imageLocationLabel = new System.Windows.Forms.Label();
            this.imageLocation = new System.Windows.Forms.TextBox();
            this.deleteImageLabel = new System.Windows.Forms.Label();
            this.deleteButton = new System.Windows.Forms.Button();
            this.imagesList = new System.Windows.Forms.ComboBox();
            this.insertButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.imageDescription = new System.Windows.Forms.TextBox();
            this.imagePath = new System.Windows.Forms.TextBox();
            this.imageName = new System.Windows.Forms.TextBox();
            this.openFileDialogImage = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // selectImage
            // 
            this.selectImage.Location = new System.Drawing.Point(105, 192);
            this.selectImage.Name = "selectImage";
            this.selectImage.Size = new System.Drawing.Size(171, 28);
            this.selectImage.TabIndex = 58;
            this.selectImage.Text = "Select Image";
            this.selectImage.UseVisualStyleBackColor = true;
            this.selectImage.Click += new System.EventHandler(this.selectImage_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(100, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(176, 29);
            this.label5.TabIndex = 57;
            this.label5.Text = "Fill every field!";
            // 
            // updateButton
            // 
            this.updateButton.Location = new System.Drawing.Point(596, 269);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(188, 42);
            this.updateButton.TabIndex = 56;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Visible = false;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // editPersonsLabel
            // 
            this.editPersonsLabel.AutoSize = true;
            this.editPersonsLabel.Location = new System.Drawing.Point(511, 246);
            this.editPersonsLabel.Name = "editPersonsLabel";
            this.editPersonsLabel.Size = new System.Drawing.Size(66, 13);
            this.editPersonsLabel.TabIndex = 55;
            this.editPersonsLabel.Text = "Edit Persons";
            this.editPersonsLabel.Visible = false;
            // 
            // editLocationLabel
            // 
            this.editLocationLabel.AutoSize = true;
            this.editLocationLabel.Location = new System.Drawing.Point(511, 220);
            this.editLocationLabel.Name = "editLocationLabel";
            this.editLocationLabel.Size = new System.Drawing.Size(69, 13);
            this.editLocationLabel.TabIndex = 54;
            this.editLocationLabel.Text = "Edit Location";
            this.editLocationLabel.Visible = false;
            // 
            // editDescriptionLabel
            // 
            this.editDescriptionLabel.AutoSize = true;
            this.editDescriptionLabel.Location = new System.Drawing.Point(511, 194);
            this.editDescriptionLabel.Name = "editDescriptionLabel";
            this.editDescriptionLabel.Size = new System.Drawing.Size(81, 13);
            this.editDescriptionLabel.TabIndex = 53;
            this.editDescriptionLabel.Text = "Edit Description";
            this.editDescriptionLabel.Visible = false;
            // 
            // editPathLabel
            // 
            this.editPathLabel.AutoSize = true;
            this.editPathLabel.Location = new System.Drawing.Point(511, 168);
            this.editPathLabel.Name = "editPathLabel";
            this.editPathLabel.Size = new System.Drawing.Size(50, 13);
            this.editPathLabel.TabIndex = 52;
            this.editPathLabel.Text = "Edit Path";
            this.editPathLabel.Visible = false;
            // 
            // editNameLabel
            // 
            this.editNameLabel.AutoSize = true;
            this.editNameLabel.Location = new System.Drawing.Point(511, 142);
            this.editNameLabel.Name = "editNameLabel";
            this.editNameLabel.Size = new System.Drawing.Size(56, 13);
            this.editNameLabel.TabIndex = 51;
            this.editNameLabel.Text = "Edit Name";
            this.editNameLabel.Visible = false;
            // 
            // editPersonsText
            // 
            this.editPersonsText.Location = new System.Drawing.Point(596, 243);
            this.editPersonsText.Name = "editPersonsText";
            this.editPersonsText.Size = new System.Drawing.Size(188, 20);
            this.editPersonsText.TabIndex = 50;
            this.editPersonsText.Visible = false;
            // 
            // editLocationText
            // 
            this.editLocationText.Location = new System.Drawing.Point(596, 217);
            this.editLocationText.Name = "editLocationText";
            this.editLocationText.Size = new System.Drawing.Size(188, 20);
            this.editLocationText.TabIndex = 49;
            this.editLocationText.Visible = false;
            // 
            // editDescriptionText
            // 
            this.editDescriptionText.Location = new System.Drawing.Point(596, 191);
            this.editDescriptionText.Name = "editDescriptionText";
            this.editDescriptionText.Size = new System.Drawing.Size(188, 20);
            this.editDescriptionText.TabIndex = 48;
            this.editDescriptionText.Visible = false;
            // 
            // editPathText
            // 
            this.editPathText.Location = new System.Drawing.Point(596, 165);
            this.editPathText.Name = "editPathText";
            this.editPathText.Size = new System.Drawing.Size(188, 20);
            this.editPathText.TabIndex = 47;
            this.editPathText.Visible = false;
            // 
            // editNameText
            // 
            this.editNameText.Location = new System.Drawing.Point(596, 139);
            this.editNameText.Name = "editNameText";
            this.editNameText.Size = new System.Drawing.Size(188, 20);
            this.editNameText.TabIndex = 46;
            this.editNameText.Visible = false;
            // 
            // editButton
            // 
            this.editButton.Location = new System.Drawing.Point(596, 89);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(188, 42);
            this.editButton.TabIndex = 45;
            this.editButton.Text = "Edit";
            this.editButton.UseVisualStyleBackColor = true;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(147, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 13);
            this.label4.TabIndex = 44;
            this.label4.Text = "Comma Separated!";
            // 
            // imagePersonsLabel
            // 
            this.imagePersonsLabel.AutoSize = true;
            this.imagePersonsLabel.Location = new System.Drawing.Point(8, 169);
            this.imagePersonsLabel.Name = "imagePersonsLabel";
            this.imagePersonsLabel.Size = new System.Drawing.Size(77, 13);
            this.imagePersonsLabel.TabIndex = 43;
            this.imagePersonsLabel.Text = "Image Persons";
            // 
            // imagePersons
            // 
            this.imagePersons.Location = new System.Drawing.Point(105, 166);
            this.imagePersons.Name = "imagePersons";
            this.imagePersons.Size = new System.Drawing.Size(171, 20);
            this.imagePersons.TabIndex = 42;
            // 
            // imageLocationLabel
            // 
            this.imageLocationLabel.AutoSize = true;
            this.imageLocationLabel.Location = new System.Drawing.Point(8, 122);
            this.imageLocationLabel.Name = "imageLocationLabel";
            this.imageLocationLabel.Size = new System.Drawing.Size(80, 13);
            this.imageLocationLabel.TabIndex = 41;
            this.imageLocationLabel.Text = "Image Location";
            // 
            // imageLocation
            // 
            this.imageLocation.Location = new System.Drawing.Point(105, 119);
            this.imageLocation.Name = "imageLocation";
            this.imageLocation.Size = new System.Drawing.Size(171, 20);
            this.imageLocation.TabIndex = 40;
            // 
            // deleteImageLabel
            // 
            this.deleteImageLabel.AutoSize = true;
            this.deleteImageLabel.Location = new System.Drawing.Point(499, 13);
            this.deleteImageLabel.Name = "deleteImageLabel";
            this.deleteImageLabel.Size = new System.Drawing.Size(93, 13);
            this.deleteImageLabel.TabIndex = 39;
            this.deleteImageLabel.Text = "Delete/Edit Image";
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(596, 40);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(188, 43);
            this.deleteButton.TabIndex = 38;
            this.deleteButton.Text = "Delete";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // imagesList
            // 
            this.imagesList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.imagesList.FormattingEnabled = true;
            this.imagesList.Location = new System.Drawing.Point(596, 10);
            this.imagesList.Name = "imagesList";
            this.imagesList.Size = new System.Drawing.Size(188, 21);
            this.imagesList.TabIndex = 37;
            // 
            // insertButton
            // 
            this.insertButton.Location = new System.Drawing.Point(105, 226);
            this.insertButton.Name = "insertButton";
            this.insertButton.Size = new System.Drawing.Size(171, 28);
            this.insertButton.TabIndex = 36;
            this.insertButton.Text = "Insert";
            this.insertButton.UseVisualStyleBackColor = true;
            this.insertButton.Click += new System.EventHandler(this.insertButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 35;
            this.label3.Text = "Image Description";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 34;
            this.label2.Text = "Image Path";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 33;
            this.label1.Text = "Image Name";
            // 
            // imageDescription
            // 
            this.imageDescription.Location = new System.Drawing.Point(105, 93);
            this.imageDescription.Name = "imageDescription";
            this.imageDescription.Size = new System.Drawing.Size(171, 20);
            this.imageDescription.TabIndex = 32;
            // 
            // imagePath
            // 
            this.imagePath.Location = new System.Drawing.Point(105, 67);
            this.imagePath.Name = "imagePath";
            this.imagePath.Size = new System.Drawing.Size(171, 20);
            this.imagePath.TabIndex = 31;
            // 
            // imageName
            // 
            this.imageName.Location = new System.Drawing.Point(105, 41);
            this.imageName.Name = "imageName";
            this.imageName.Size = new System.Drawing.Size(171, 20);
            this.imageName.TabIndex = 30;
            // 
            // openFileDialogImage
            // 
            this.openFileDialogImage.FileName = "openFileDialogImage";
            // 
            // ClientImagesGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.selectImage);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.editPersonsLabel);
            this.Controls.Add(this.editLocationLabel);
            this.Controls.Add(this.editDescriptionLabel);
            this.Controls.Add(this.editPathLabel);
            this.Controls.Add(this.editNameLabel);
            this.Controls.Add(this.editPersonsText);
            this.Controls.Add(this.editLocationText);
            this.Controls.Add(this.editDescriptionText);
            this.Controls.Add(this.editPathText);
            this.Controls.Add(this.editNameText);
            this.Controls.Add(this.editButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.imagePersonsLabel);
            this.Controls.Add(this.imagePersons);
            this.Controls.Add(this.imageLocationLabel);
            this.Controls.Add(this.imageLocation);
            this.Controls.Add(this.deleteImageLabel);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.imagesList);
            this.Controls.Add(this.insertButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.imageDescription);
            this.Controls.Add(this.imagePath);
            this.Controls.Add(this.imageName);
            this.Name = "ClientImagesGUI";
            this.Text = "ClientImagesGUI";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button selectImage;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Label editPersonsLabel;
        private System.Windows.Forms.Label editLocationLabel;
        private System.Windows.Forms.Label editDescriptionLabel;
        private System.Windows.Forms.Label editPathLabel;
        private System.Windows.Forms.Label editNameLabel;
        private System.Windows.Forms.TextBox editPersonsText;
        private System.Windows.Forms.TextBox editLocationText;
        private System.Windows.Forms.TextBox editDescriptionText;
        private System.Windows.Forms.TextBox editPathText;
        private System.Windows.Forms.TextBox editNameText;
        private System.Windows.Forms.Button editButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label imagePersonsLabel;
        private System.Windows.Forms.TextBox imagePersons;
        private System.Windows.Forms.Label imageLocationLabel;
        private System.Windows.Forms.TextBox imageLocation;
        private System.Windows.Forms.Label deleteImageLabel;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.ComboBox imagesList;
        private System.Windows.Forms.Button insertButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox imageDescription;
        private System.Windows.Forms.TextBox imagePath;
        private System.Windows.Forms.TextBox imageName;
        private System.Windows.Forms.OpenFileDialog openFileDialogImage;
    }
}

